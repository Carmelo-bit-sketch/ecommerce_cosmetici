# E-commerce Cosmetici (Python + SQLAlchemy)

Gestione database normalizzato di un e-commerce di cosmetici.
Include:
- Modelli ORM SQLAlchemy
- Creazione e popolamento tabelle (CRUD)
- Esempi di uso (in main.py)

Configurare la stringa di connessione nel file main.py per usare MySQL.
